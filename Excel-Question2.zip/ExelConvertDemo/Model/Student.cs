﻿
using System;
using ExelConvertDemo.Model;
using System.Collections.Generic;
using System.Text;
using System.Drawing.Imaging;
using System.IO;
using Microsoft.VisualBasic;
using System.Runtime.InteropServices;
using System.Dynamic;
using System.Threading;
using System.Reflection;
using System.Linq;

namespace ExelConvertDemo.Model
{
    public class Student

    {
        public string StudentCode { get; set; }
        public string StudentID { get; set; }
        public string FirstName { get; set; }
        public int Record { get; set; }
        public string LastName { get; set; }

        private string _DateOfBirthString;
        public string ImageData { get; set; }
        public DateTime DateofBirth { get; set; }
        public static int sum = 0;
        public static int Count2 = 0;
        public static int low;
        public int age;
        public List<int> age1 = new List<int>();
        public string DateOfBirthString
        {
            get
            {
                return _DateOfBirthString;

            }
            set
            {
                _DateOfBirthString = value;
                DateTime datetime;
                if (DateTime.TryParse(_DateOfBirthString, out datetime) == true)
                {
                    DateofBirth = datetime;
                }
            }
        }
       

        public void FromDirectory(string direct)
        {
            string[] directoryPart = direct.Split(" ", StringSplitOptions.None); //Splits the directory part by a space.
            StudentCode = directoryPart[0];
            try
            {
                StudentID += 1;
                FirstName = directoryPart[1];
                LastName = directoryPart[2];
            }
            catch
            {

            }
            
            
        }

        public void FromCsv(string csvDataLine)
        {
            string[] CsvDataLineParts = csvDataLine.Split(",", StringSplitOptions.None); //Splits the csv by comma.
            DateOfBirthString = CsvDataLineParts[3];
            ImageData = CsvDataLineParts[4];     
        }

        public override string ToString()
        {
            return $"{StudentCode}-{FirstName},{LastName},{DateOfBirthString},{Record}";


        }
  
        //Displays the content in csv format.
    public string ToCSV()
        {
            
            string result = $"{StudentCode},{FirstName},{LastName},{DateOfBirthString},{Record}";
            return result;
        }



    }



}
