﻿using System;
using Assign3.Model.Utilities;
using Assign3.Model;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using System.Text.Json;
using System.Xml;
using Newtonsoft.Json.Linq;
using JsonSerializer = Newtonsoft.Json.JsonSerializer;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

namespace Assign3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creates a list named directories
            
            List<Student> students = new List<Student>(); //Creates a list named students.
            var direct = "200467080 Manoj Gottumukkala";
            List<string> directories = FTP.GetDirectory(Constants.FTP.BaseUrl);
            foreach (var directory in directories)
            {
                Console.WriteLine(directory);
            }
            int counta = 1;          
            foreach (var directory in directories)  //Iterates through each element in the list directory.
            {
                
                Student student = new Student();        //Creates a student object.
                student.FromDirectory(directory);       //Calls the FromDirectory method.
                var fileBytes = FTP.DownloadFileBytes(Constants.FTP.BaseUrl + "/" + directory + "/info.csv"); //Downloads the bytes of each file in the directory.
                string infoCsvData = Encoding.UTF8.GetString(fileBytes, 0, fileBytes.Length);  
                string[] lines = infoCsvData.Split("\r\n", StringSplitOptions.RemoveEmptyEntries); //Splits by return-carriage
                try
                {
                    student.FromCsv(lines[1]);   //inputs the second column of the csv file which is the data record.
                    students.Add(student);         //Adds student to students list. 
                    Student abc = students.Find(x => x.FirstName == "Manoj");  //Checks if the first name is manoj from the students list.
                                                                               //Checks if abc is not null and the value of counta (The reason for counta=1 is, the loop only triggers for the first occurance of my name in the list)
                    if (abc != null && counta == 1)
                    {
                        student.Record = true;   //Sets my record to true when my name enters the list for the first time.
                        counta = counta + 1;
                    }
                    else
                    {
                        student.Record = false;  //Sets false to other directories.
                    }
                    //string output = student.ToCSV();
                    //Console.WriteLine(output);
                    Console.WriteLine(student.ToString());
                    string fileName = "C:\\Users\\Owner\\Desktop\\myimage.jpg";


                    WordprocessingDocument wordprocessingDocument = WordprocessingDocument.Open("C:\\Users\\Owner\\Desktop\\info(1).docx", true);
                    
                    // Assign a reference to the existing document body.
                    MainDocumentPart mainPart = wordprocessingDocument.MainDocumentPart;
                    Body body = wordprocessingDocument.MainDocumentPart.Document.Body;
                    // Add new text.
                    Paragraph para = body.AppendChild(new Paragraph());
                    Run run = para.AppendChild(new Run());
                    run.AppendChild(new Text("Hello my name is " + student.FirstName + "  " + student.LastName));
                    run.AppendChild(new Break() { Type = BreakValues.Page });  
                    Student.Graph(wordprocessingDocument, fileName);
                    wordprocessingDocument.Close();
                }
                catch
                {

                }
            }


            //The below code uploads the csv to my folder.commented to prevent frequent uploads.

            string localUploadFilePath = @"C:\Users\Owner\Desktop\info.docx";
            string remoteUploadFileDestination = "/200467080 Manoj Gottumukkala/students.csv";
            Console.WriteLine(FTP.UploadFile(localUploadFilePath, Constants.FTP.BaseUrl + remoteUploadFileDestination));


        }
    }

}